import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import { Construct } from 'constructs';
export interface CertificateStackProps {
    domainName: string;
    includeWww?: boolean;
    additionalDomains?: string[];
    hostedZoneId?: string;
    hostedZoneName?: string;
}
export declare class CertificateStack extends Construct {
    readonly certificate: acm.Certificate;
    readonly certificateArn: string;
    constructor(scope: Construct, id: string, props: CertificateStackProps);
}
