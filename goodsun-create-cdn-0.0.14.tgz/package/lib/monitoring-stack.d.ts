import { Construct } from 'constructs';
export interface MonitoringStackProps {
    certificateArns: string[];
    notificationEmail: string;
}
export declare class MonitoringStack extends Construct {
    constructor(scope: Construct, id: string, props: MonitoringStackProps);
}
