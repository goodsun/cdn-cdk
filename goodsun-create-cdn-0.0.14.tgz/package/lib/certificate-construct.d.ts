import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import { Construct } from 'constructs';
export interface CertificateConstructProps {
    domainName: string;
    hostedZoneId?: string;
    hostedZoneName?: string;
}
export declare class CertificateConstruct extends Construct {
    readonly certificate: acm.Certificate;
    readonly certificateArn: string;
    constructor(scope: Construct, id: string, props: CertificateConstructProps);
}
