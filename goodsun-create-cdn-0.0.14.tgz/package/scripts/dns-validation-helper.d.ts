#!/usr/bin/env node
interface DnsValidationRecord {
    Name: string;
    Type: string;
    Value: string;
}
interface DnsProvider {
    name: string;
    instructions: string;
    scriptPath?: string;
}
declare class DnsValidationHelper {
    private acm;
    constructor(regionParam?: string);
    getCertificateValidationRecords(certificateArn: string): Promise<DnsValidationRecord[]>;
    displayProviderInstructions(provider: DnsProvider, records: DnsValidationRecord[]): void;
    generateDnsRecordsFile(records: DnsValidationRecord[], filename?: string): void;
    checkValidationStatus(certificateArn: string): Promise<boolean>;
    waitForValidation(certificateArn: string, maxAttempts?: number): Promise<boolean>;
}
export { DnsValidationHelper, DnsValidationRecord };
