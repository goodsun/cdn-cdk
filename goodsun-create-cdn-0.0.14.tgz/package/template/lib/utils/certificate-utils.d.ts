import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import { Construct } from 'constructs';
export interface ExistingCertificateInfo {
    certificateArn: string;
    domainName: string;
    isWildcard: boolean;
}
export declare class CertificateUtils {
    /**
     * Check if a domain can use an existing wildcard certificate
     * @param domain The domain to check (e.g., "dev.example.com")
     * @returns The wildcard domain if applicable (e.g., "*.example.com"), null otherwise
     */
    static getWildcardDomainForSubdomain(domain: string): string | null;
    /**
     * Check for existing certificate in SSM Parameter Store
     * @param scope CDK construct scope
     * @param domain The domain to check
     * @returns Certificate ARN if exists, null otherwise
     */
    static checkExistingCertificateInSSM(scope: Construct, domain: string): string | null;
    /**
     * Get or create certificate with wildcard support
     * @param scope CDK construct scope
     * @param id Construct ID
     * @param domain The domain name
     * @param region The AWS region
     * @returns Certificate interface
     */
    static getOrCreateCertificate(scope: Construct, id: string, domain: string, region: string): acm.ICertificate;
}
