import * as cdk from 'aws-cdk-lib';
import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import { Construct } from 'constructs';
export interface CloudFrontCertificateStackProps extends cdk.StackProps {
    domainName: string;
}
export declare class CloudFrontCertificateStack extends cdk.Stack {
    readonly certificate: acm.Certificate;
    constructor(scope: Construct, id: string, props: CloudFrontCertificateStackProps);
}
