import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
export interface CdnStackProps extends cdk.StackProps {
    domain: string;
    useCloudFront: boolean;
    useMonitoring: boolean;
    notificationEmail?: string;
    originType?: string;
    originDomain?: string;
    originPath?: string;
}
export declare class CdnStack extends cdk.Stack {
    constructor(scope: Construct, id: string, props: CdnStackProps);
}
